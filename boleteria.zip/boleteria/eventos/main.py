"""Microservicio de Eventos · esquema_eventos (Tabla 51) · RF-EVE-01 a 03."""
from datetime import date, time
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, StringConstraints
from sqlalchemy import Date, Enum, Index, Integer, String, Text, Time, func, or_, select
from sqlalchemy.orm import Mapped, Session, mapped_column

from common import auditoria
from common.app import ahora_local, crear_app, hoy_local
from common.auth import requiere
from common.clients import boletas, disponibilidad, escenarios, ids_param, parse_ids, reservas
from common.errors import ErrorServicio, ServicioNoDisponible
from common.security import exigir_clave_interna

from .database import Base, engine, get_db, preparar


class Evento(Base):
    __tablename__ = "evento"
    __table_args__ = (Index("ix_evento_estado_fecha", "estado", "fecha"),)

    id_evento: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    id_escenario: Mapped[int] = mapped_column(Integer, nullable=False, index=True)  # RL -> Escenarios
    nombre: Mapped[str] = mapped_column(String(120), nullable=False)
    descripcion: Mapped[str | None] = mapped_column(Text)
    fecha: Mapped[date] = mapped_column(Date, nullable=False)
    hora: Mapped[time] = mapped_column(Time, nullable=False)
    estado: Mapped[str] = mapped_column(
        Enum("programado", "realizado", "cancelado", name="estado_evento"),
        nullable=False, default="programado")


Nombre = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=120)]
Descripcion = Annotated[str, StringConstraints(strip_whitespace=True, max_length=2000)]


class EventoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id_escenario: int
    nombre: Nombre
    descripcion: Descripcion | None = None
    fecha: date
    hora: time


class EventoUpd(BaseModel):
    model_config = ConfigDict(extra="forbid")
    nombre: Nombre
    descripcion: Descripcion | None = None
    fecha: date
    hora: time


class EstadoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    estado: Literal["realizado", "cancelado"]


class EscenarioMini(BaseModel):
    id_escenario: int
    nombre: str
    direccion: str
    capacidad: int


class EventoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id_evento: int
    id_escenario: int
    nombre: str
    descripcion: str | None
    fecha: date
    hora: time
    estado: str
    escenario: EscenarioMini | None = None


router = APIRouter()


def _obtener(db: Session, id_evento: int) -> Evento:
    e = db.get(Evento, id_evento)
    if e is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "El evento no existe")
    return e


def _enriquecer(lista: list[Evento]) -> list[EventoOut]:
    """Agrega el escenario de cada evento consultando al microservicio de Escenarios."""
    salida = [EventoOut.model_validate(e) for e in lista]
    if not salida:
        return salida
    try:
        mapa = {x["id_escenario"]: x for x in escenarios.get(
            "/internal/escenarios", ids=ids_param(e.id_escenario for e in salida))}
    except ServicioNoDisponible:
        mapa = {}
    for e in salida:
        if e.id_escenario in mapa:
            e.escenario = EscenarioMini(**mapa[e.id_escenario])
    return salida


def _validar_fecha(fecha: date, hora: time) -> None:
    if fecha < hoy_local() or (fecha == hoy_local() and hora <= ahora_local().time()):
        raise HTTPException(422, "La fecha y hora del evento deben ser futuras")


def _publicar(id_evento: int, id_escenario: int) -> dict:
    """RF-DIS-01: crea un registro de disponibilidad por cada asiento del escenario."""
    try:
        return disponibilidad.post("/internal/disponibilidad/publicar",
                                   {"id_evento": id_evento, "id_escenario": id_escenario})
    except (ErrorServicio, ServicioNoDisponible) as exc:
        return {"publicados": 0, "total": 0, "error": str(exc)}


# ---------------- Consulta (usuarios) ----------------
@router.get("/eventos", response_model=list[EventoOut], tags=["Eventos"],
            summary="RF-EVE-03 Consultar eventos programados")
def listar(q: str | None = None, id_escenario: int | None = None, desde: date | None = None,
           hasta: date | None = None, _: dict = Depends(requiere("consultar_eventos")),
           db: Session = Depends(get_db)):
    consulta = select(Evento).where(Evento.estado == "programado", Evento.fecha >= hoy_local())
    if q:
        patron = f"%{q.strip()}%"
        consulta = consulta.where(or_(Evento.nombre.ilike(patron), Evento.descripcion.ilike(patron)))
    if id_escenario:
        consulta = consulta.where(Evento.id_escenario == id_escenario)
    if desde:
        consulta = consulta.where(Evento.fecha >= desde)
    if hasta:
        consulta = consulta.where(Evento.fecha <= hasta)
    return _enriquecer(db.scalars(consulta.order_by(Evento.fecha, Evento.hora)).all())


@router.get("/eventos/todos", response_model=list[EventoOut], tags=["Administración"],
            summary="Todos los eventos, en cualquier estado (administrador)")
def listar_todos(_: dict = Depends(requiere("gestionar_eventos")), db: Session = Depends(get_db)):
    return _enriquecer(db.scalars(select(Evento).order_by(Evento.fecha.desc(), Evento.hora)).all())


@router.get("/eventos/{id_evento}", response_model=EventoOut, tags=["Eventos"])
def detalle(id_evento: int, _: dict = Depends(requiere("consultar_eventos")),
            db: Session = Depends(get_db)):
    return _enriquecer([_obtener(db, id_evento)])[0]


# ---------------- Administración ----------------
@router.post("/eventos", status_code=201, tags=["Administración"], summary="RF-EVE-01 Registrar evento")
def crear(datos: EventoIn, actor: dict = Depends(requiere("gestionar_eventos")),
          db: Session = Depends(get_db)):
    escenarios.get(f"/internal/escenarios/{datos.id_escenario}")  # 404 si no existe (RN04)
    _validar_fecha(datos.fecha, datos.hora)
    e = Evento(**datos.model_dump(), estado="programado")
    db.add(e)
    db.commit()
    pub = _publicar(e.id_evento, e.id_escenario)
    auditoria.registrar("CREAR_EVENTO", "EVENTO", e.id_evento, actor["id_usuario"],
                        f"{e.nombre} · {pub.get('publicados', 0)} asientos publicados")
    return {**_enriquecer([e])[0].model_dump(mode="json"), "disponibilidad": pub}


@router.put("/eventos/{id_evento}", response_model=EventoOut, tags=["Administración"],
            summary="RF-EVE-02 Actualizar evento")
def actualizar(id_evento: int, datos: EventoUpd, actor: dict = Depends(requiere("gestionar_eventos")),
               db: Session = Depends(get_db)):
    e = _obtener(db, id_evento)
    if e.estado != "programado":
        raise HTTPException(409, f"Solo se editan eventos programados (este está {e.estado})")
    if (datos.fecha, datos.hora) != (e.fecha, e.hora):
        _validar_fecha(datos.fecha, datos.hora)
    for k, v in datos.model_dump().items():
        setattr(e, k, v)
    db.commit()
    auditoria.registrar("ACTUALIZAR_EVENTO", "EVENTO", e.id_evento, actor["id_usuario"])
    return _enriquecer([e])[0]


@router.put("/eventos/{id_evento}/estado", tags=["Administración"],
            summary="RF-EVE-02 Cancelar o marcar como realizado")
def cambiar_estado(id_evento: int, datos: EstadoIn, actor: dict = Depends(requiere("gestionar_eventos")),
                   db: Session = Depends(get_db)):
    e = _obtener(db, id_evento)
    if e.estado != "programado":
        raise HTTPException(409, f"El evento ya está {e.estado}")
    e.estado = datos.estado
    db.commit()
    efectos = {}
    if datos.estado == "cancelado":
        # Cancelar impide nuevas reservas y compras; se liberan las reservas activas y se
        # anulan las boletas emitidas. Los registros se conservan (RN14).
        for nombre, svc, ruta in (("reservas_canceladas", reservas, "/internal/reservas/cancelar-por-evento"),
                                  ("boletas_canceladas", boletas, "/internal/boletas/cancelar-por-evento")):
            try:
                efectos[nombre] = svc.post(f"{ruta}/{id_evento}")["total"]
            except (ErrorServicio, ServicioNoDisponible):
                efectos[nombre] = None
    auditoria.registrar("CANCELAR_EVENTO" if datos.estado == "cancelado" else "EVENTO_REALIZADO",
                        "EVENTO", id_evento, actor["id_usuario"], e.nombre)
    return {**_enriquecer([e])[0].model_dump(mode="json"), **efectos}


@router.post("/eventos/{id_evento}/publicar", tags=["Administración"],
             summary="RF-DIS-01 Volver a publicar la disponibilidad (asientos nuevos)")
def publicar(id_evento: int, actor: dict = Depends(requiere("gestionar_eventos")),
             db: Session = Depends(get_db)):
    e = _obtener(db, id_evento)
    if e.estado != "programado":
        raise HTTPException(409, "Solo se publica la disponibilidad de eventos programados")
    pub = disponibilidad.post("/internal/disponibilidad/publicar",
                              {"id_evento": e.id_evento, "id_escenario": e.id_escenario})
    auditoria.registrar("PUBLICAR_DISPONIBILIDAD", "EVENTO", id_evento, actor["id_usuario"],
                        f"{pub['publicados']} nuevos")
    return pub


# ---------------- Internas ----------------
@router.get("/internal/eventos/contar", include_in_schema=False, dependencies=[Depends(exigir_clave_interna)])
def interno_contar(id_escenario: int, db: Session = Depends(get_db)):
    return {"total": db.scalar(select(func.count()).select_from(Evento)
                               .where(Evento.id_escenario == id_escenario))}


@router.get("/internal/eventos", response_model=list[EventoOut], include_in_schema=False,
            dependencies=[Depends(exigir_clave_interna)])
def interno_varios(ids: str = "", id_escenario: int | None = None, estado: str | None = None,
                   db: Session = Depends(get_db)):
    q = select(Evento)
    if ids:
        q = q.where(Evento.id_evento.in_(parse_ids(ids)))
    if id_escenario:
        q = q.where(Evento.id_escenario == id_escenario)
    if estado:
        q = q.where(Evento.estado == estado)
    return _enriquecer(db.scalars(q).all())


@router.get("/internal/eventos/{id_evento}", response_model=EventoOut, include_in_schema=False,
            dependencies=[Depends(exigir_clave_interna)])
def interno_uno(id_evento: int, db: Session = Depends(get_db)):
    return _enriquecer([_obtener(db, id_evento)])[0]


app = crear_app("eventos", "Microservicio de Eventos",
                "Administrar los eventos y ofrecer su consulta (RF-EVE-01 a 03).",
                router, Base, engine, preparar)

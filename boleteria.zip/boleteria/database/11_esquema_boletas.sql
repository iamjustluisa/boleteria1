-- Microservicio de Boletas · Tabla 58
-- UNIQUE (id_evento, id_asiento): un asiento no se vende dos veces en el mismo evento (RN15).
USE esquema_boletas;

CREATE TABLE IF NOT EXISTS boleta (
    id_boleta     INT AUTO_INCREMENT PRIMARY KEY,
    id_compra     INT           NOT NULL,             -- RL -> Compras
    id_evento     INT           NOT NULL,             -- RL -> Eventos
    id_asiento    INT           NOT NULL,             -- RL -> Asientos
    codigo_boleta VARCHAR(40)   NOT NULL,
    precio        DECIMAL(10,2) NOT NULL,
    estado        ENUM('vigente','usada','cancelada') NOT NULL DEFAULT 'vigente',
    CONSTRAINT uq_boleta_codigo UNIQUE (codigo_boleta),
    CONSTRAINT uq_boleta_evento_asiento UNIQUE (id_evento, id_asiento),
    CONSTRAINT ck_boleta_precio CHECK (precio >= 0),
    INDEX ix_boleta_id_compra (id_compra)
) ENGINE=InnoDB;

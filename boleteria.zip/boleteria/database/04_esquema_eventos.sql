-- Microservicio de Eventos · Tabla 51
-- id_escenario es referencia lógica (RL) a esquema_escenarios.escenario: la valida el servicio.
USE esquema_eventos;

CREATE TABLE IF NOT EXISTS evento (
    id_evento    INT AUTO_INCREMENT PRIMARY KEY,
    id_escenario INT          NOT NULL,
    nombre       VARCHAR(120) NOT NULL,
    descripcion  TEXT,
    fecha        DATE         NOT NULL,
    hora         TIME         NOT NULL,
    estado       ENUM('programado','realizado','cancelado') NOT NULL DEFAULT 'programado',
    INDEX ix_evento_id_escenario (id_escenario),
    INDEX ix_evento_estado_fecha (estado, fecha)
) ENGINE=InnoDB;

-- Microservicio de Pagos · Tabla 57 (pago simulado)
USE esquema_pagos;

CREATE TABLE IF NOT EXISTS pago (
    id_pago    INT AUTO_INCREMENT PRIMARY KEY,
    id_compra  INT           NOT NULL,                -- RL -> Compras
    valor      DECIMAL(12,2) NOT NULL,
    fecha_pago DATETIME      NOT NULL,
    estado     ENUM('aprobado','rechazado') NOT NULL,
    referencia VARCHAR(60)   NOT NULL,
    CONSTRAINT uq_pago_referencia UNIQUE (referencia),
    CONSTRAINT ck_pago_valor CHECK (valor >= 0),
    INDEX ix_pago_id_compra (id_compra)
) ENGINE=InnoDB;

"""Microservicio de Boletas · esquema_boletas (Tabla 58) · RF-BOL-01 a 03.

Se emite una boleta por asiento de una compra pagada (RN18), con código único. La llave
UNIQUE (id_evento, id_asiento) impide más de una boleta por asiento y evento (RF-BOL-03, RN15).
La boleta no guarda el usuario: la propiedad se valida a través de la compra (RNF02).
"""
import io
import re
import secrets
from collections import defaultdict
from decimal import Decimal

import qrcode
import qrcode.image.svg
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import CheckConstraint, Enum, Integer, Numeric, String, UniqueConstraint, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Mapped, Session, mapped_column

from common import auditoria
from common.app import crear_app
from common.auth import es_admin, requiere, sesion_actual
from common.clients import asientos, compras, eventos, ids_param, localidades, usuarios
from common.errors import ServicioNoDisponible
from common.security import exigir_clave_interna

from .database import Base, engine, get_db, preparar

_ALFABETO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # sin caracteres ambiguos (0/O, 1/I)


class Boleta(Base):
    __tablename__ = "boleta"
    __table_args__ = (
        UniqueConstraint("id_evento", "id_asiento", name="uq_boleta_evento_asiento"),
        CheckConstraint("precio >= 0", name="ck_boleta_precio"),
    )
    id_boleta: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    id_compra: Mapped[int] = mapped_column(Integer, nullable=False, index=True)   # RL -> Compras
    id_evento: Mapped[int] = mapped_column(Integer, nullable=False)               # RL -> Eventos
    id_asiento: Mapped[int] = mapped_column(Integer, nullable=False)              # RL -> Asientos
    codigo_boleta: Mapped[str] = mapped_column(String(40), nullable=False, unique=True)
    precio: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    estado: Mapped[str] = mapped_column(Enum("vigente", "usada", "cancelada", name="estado_boleta"),
                                        nullable=False, default="vigente")


class ItemIn(BaseModel):
    id_asiento: int
    precio: Decimal = Field(ge=0)


class GenerarIn(BaseModel):
    id_compra: int
    id_evento: int
    items: list[ItemIn] = Field(min_length=1)


def _codigo() -> str:
    return "BOL-" + "".join(secrets.choice(_ALFABETO) for _ in range(10))


def _salida(b: Boleta) -> dict:
    return {"id_boleta": b.id_boleta, "id_compra": b.id_compra, "id_evento": b.id_evento,
            "id_asiento": b.id_asiento, "codigo_boleta": b.codigo_boleta, "precio": float(b.precio),
            "estado": b.estado}


def _enriquecer(lista: list[Boleta]) -> list[dict]:
    salida = [_salida(b) for b in lista]
    if not salida:
        return salida
    try:
        evs = {e["id_evento"]: e for e in eventos.get("/internal/eventos", ids=ids_param({b.id_evento for b in lista}))}
        sillas = {a["id_asiento"]: a for a in asientos.get("/internal/asientos", ids=ids_param({b.id_asiento for b in lista}))}
        locs = {l["id_localidad"]: l for l in localidades.get(
            "/internal/localidades", ids=ids_param({a["id_localidad"] for a in sillas.values()}))} if sillas else {}
    except ServicioNoDisponible:
        return salida
    for d in salida:
        a = sillas.get(d["id_asiento"], {})
        d["evento"] = evs.get(d["id_evento"])
        d["fila"], d["numero"] = a.get("fila"), a.get("numero")
        d["localidad"] = locs.get(a.get("id_localidad"), {}).get("nombre")
    return salida


def _compras_de(id_usuario: int) -> list[int]:
    return [c["id_compra"] for c in compras.get("/internal/compras", id_usuario=id_usuario)]


router = APIRouter()


@router.get("/boletas/mis", tags=["Boletas"], summary="RF-BOL-02 Consultar mis boletas")
def mis_boletas(info: dict = Depends(sesion_actual), db: Session = Depends(get_db)):
    ids = _compras_de(info["id_usuario"])
    if not ids:
        return []
    return _enriquecer(db.scalars(select(Boleta).where(Boleta.id_compra.in_(ids))
                                  .order_by(Boleta.id_boleta.desc())).all())


@router.get("/boletas/resumen", tags=["Administración"], summary="Ventas por evento (administrador)")
def resumen(_: dict = Depends(requiere("consultar_auditoria")), db: Session = Depends(get_db)):
    grupos: dict[int, dict] = defaultdict(lambda: {"vendidas": 0, "ingresos": 0.0, "usadas": 0, "canceladas": 0})
    for b in db.scalars(select(Boleta)):
        g = grupos[b.id_evento]
        if b.estado == "cancelada":
            g["canceladas"] += 1
            continue
        g["vendidas"] += 1
        g["ingresos"] += float(b.precio)
        g["usadas"] += b.estado == "usada"
    evs = {e["id_evento"]: e for e in eventos.get("/internal/eventos", ids=ids_param(grupos))} if grupos else {}
    filas = [{"id_evento": k, "evento": evs.get(k, {}).get("nombre"), "fecha": evs.get(k, {}).get("fecha"),
              "estado_evento": evs.get(k, {}).get("estado"), **v, "ingresos": round(v["ingresos"], 2)}
             for k, v in grupos.items()]
    filas.sort(key=lambda f: -f["ingresos"])
    return {"eventos": filas, "total_boletas": sum(f["vendidas"] for f in filas),
            "total_ingresos": round(sum(f["ingresos"] for f in filas), 2)}


@router.get("/boletas/qr/{codigo}.svg", tags=["Boletas"], summary="Código QR de una boleta (SVG)")
def qr(codigo: str):
    if not re.fullmatch(r"BOL-[A-Z0-9]{6,36}", codigo):
        raise HTTPException(404, "Código inválido")
    img = qrcode.make(codigo, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
    buf = io.BytesIO()
    img.save(buf)
    return Response(buf.getvalue(), media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=86400"})


@router.get("/boletas/{codigo}", tags=["Boletas"], summary="Consultar una boleta por su código")
def por_codigo(codigo: str, info: dict = Depends(sesion_actual), db: Session = Depends(get_db)):
    b = db.scalar(select(Boleta).where(Boleta.codigo_boleta == codigo.strip().upper()))
    if b is None or (not es_admin(info) and b.id_compra not in _compras_de(info["id_usuario"])):
        raise HTTPException(404, "La boleta no existe")
    d = _enriquecer([b])[0]
    if es_admin(info):
        c = compras.get(f"/internal/compras/{b.id_compra}")
        u = usuarios.get_o_none(f"/internal/usuarios/{c['id_usuario']}")
        d["titular"] = f"{u['nombre']} {u['apellido']}" if u else None
    return d


@router.put("/boletas/{codigo}/usar", tags=["Administración"], summary="Marcar una boleta como usada (ingreso)")
def usar(codigo: str, actor: dict = Depends(requiere("gestionar_eventos")), db: Session = Depends(get_db)):
    b = db.scalar(select(Boleta).where(Boleta.codigo_boleta == codigo.strip().upper()))
    if b is None:
        raise HTTPException(404, "La boleta no existe")
    if b.estado != "vigente":
        raise HTTPException(409, f"La boleta ya está {b.estado}")
    b.estado = "usada"
    db.commit()
    auditoria.registrar("BOLETA_USADA", "BOLETA", b.id_boleta, actor["id_usuario"], b.codigo_boleta)
    return _enriquecer([b])[0]


# ---------------- Internas ----------------
@router.post("/internal/boletas/generar", include_in_schema=False, dependencies=[Depends(exigir_clave_interna)])
def interno_generar(datos: GenerarIn, db: Session = Depends(get_db)):
    """RF-BOL-01. Idempotente: si la compra ya tiene boletas, las devuelve."""
    ya = db.scalars(select(Boleta).where(Boleta.id_compra == datos.id_compra)).all()
    if ya:
        return _enriquecer(ya)
    nuevas = [Boleta(id_compra=datos.id_compra, id_evento=datos.id_evento, id_asiento=i.id_asiento,
                     precio=i.precio, codigo_boleta=_codigo(), estado="vigente") for i in datos.items]
    db.add_all(nuevas)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Ya existe una boleta para uno de estos asientos en este evento")
    for b in nuevas:
        auditoria.registrar("BOLETA_EMITIDA", "BOLETA", b.id_boleta, None,
                            f"{b.codigo_boleta} compra {b.id_compra}")
    return _enriquecer(nuevas)


@router.post("/internal/boletas/cancelar-por-evento/{id_evento}", include_in_schema=False,
             dependencies=[Depends(exigir_clave_interna)])
def interno_cancelar_evento(id_evento: int, db: Session = Depends(get_db)):
    res = db.execute(update(Boleta).where(Boleta.id_evento == id_evento, Boleta.estado == "vigente")
                     .values(estado="cancelada"))
    db.commit()
    return {"total": res.rowcount}


app = crear_app("boletas", "Microservicio de Boletas",
                "Emisión y consulta de boletas de compras pagadas (RF-BOL-01 a 03).",
                router, Base, engine, preparar)

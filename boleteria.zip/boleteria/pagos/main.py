"""Microservicio de Pagos · esquema_pagos (Tabla 57) · RF-PAG-01 a 03.

Pago **simulado** (no hay pasarela real, ver alcance). Este servicio orquesta la confirmación:

  aprobado  → Reservas completa la reserva (asientos a *vendido*) → Compra *pagada* →
              Boletas emite una boleta por asiento → notificación al usuario.
  rechazado → Compra *rechazada* → Reservas libera los asientos (RN17) → sin boletas (RN18).

Tarjeta de prueba que siempre se rechaza: **4000 0000 0000 0002**. Cualquier otra tarjeta válida
(algoritmo de Luhn) se aprueba. Nunca se guarda el número de la tarjeta.
"""
import re
import uuid
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import CheckConstraint, DateTime, Enum, Integer, Numeric, String, select
from sqlalchemy.orm import Mapped, Session, mapped_column

from common import auditoria
from common.app import crear_app, hoy_local
from common.auth import es_admin, requiere, sesion_actual
from common.clients import boletas, compras, eventos, reservas
from common.errors import ErrorServicio, ServicioNoDisponible
from common.notificar import notificar
from common.security import utcnow

from .database import Base, engine, get_db, preparar

TARJETA_RECHAZO = "4000000000000002"


class Pago(Base):
    __tablename__ = "pago"
    __table_args__ = (CheckConstraint("valor >= 0", name="ck_pago_valor"),)

    id_pago: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    id_compra: Mapped[int] = mapped_column(Integer, nullable=False, index=True)  # RL -> Compras
    valor: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    fecha_pago: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    estado: Mapped[str] = mapped_column(Enum("aprobado", "rechazado", name="estado_pago"), nullable=False)
    referencia: Mapped[str] = mapped_column(String(60), nullable=False, unique=True)


def _luhn(numero: str) -> bool:
    total, alt = 0, False
    for d in reversed(numero):
        n = int(d)
        if alt:
            n = n * 2 - 9 if n > 4 else n * 2
        total += n
        alt = not alt
    return total % 10 == 0


class PagoIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id_compra: int
    titular: str = Field(min_length=3, max_length=80)
    numero_tarjeta: str
    vencimiento: str = Field(description="MM/AA")
    cvv: str

    @field_validator("numero_tarjeta")
    @classmethod
    def _tarjeta(cls, v: str) -> str:
        v = re.sub(r"[\s-]", "", v)
        if not v.isdigit() or not 13 <= len(v) <= 19 or not _luhn(v):
            raise ValueError("El número de tarjeta no es válido")
        return v

    @field_validator("vencimiento")
    @classmethod
    def _venc(cls, v: str) -> str:
        m = re.fullmatch(r"\s*(\d{2})\s*/\s*(\d{2})\s*", v)
        if not m or not 1 <= int(m.group(1)) <= 12:
            raise ValueError("Usa el formato MM/AA")
        mes, anio = int(m.group(1)), 2000 + int(m.group(2))
        hoy = hoy_local()
        if (anio, mes) < (hoy.year, hoy.month):
            raise ValueError("La tarjeta está vencida")
        return f"{mes:02d}/{anio % 100:02d}"

    @field_validator("cvv")
    @classmethod
    def _cvv(cls, v: str) -> str:
        if not re.fullmatch(r"\d{3,4}", v.strip()):
            raise ValueError("El CVV debe tener 3 o 4 dígitos")
        return v.strip()


def _salida(p: Pago) -> dict:
    return {"id_pago": p.id_pago, "id_compra": p.id_compra, "valor": float(p.valor),
            "fecha_pago": p.fecha_pago, "estado": p.estado, "referencia": p.referencia}


router = APIRouter()


def _registrar(db: Session, id_compra: int, valor: float, estado: str) -> Pago:
    p = Pago(id_compra=id_compra, valor=Decimal(str(valor)), fecha_pago=utcnow(), estado=estado,
             referencia=f"PAY-{uuid.uuid4().hex[:16].upper()}")
    db.add(p)
    db.commit()
    return p


@router.post("/pagos", status_code=201, tags=["Pagos"],
             summary="RF-PAG-01 Registrar el pago (simulado) de una compra")
def pagar(datos: PagoIn, info: dict = Depends(requiere("comprar_boletas")), db: Session = Depends(get_db)):
    compra = compras.get_o_none(f"/internal/compras/{datos.id_compra}")
    if compra is None or compra["id_usuario"] != info["id_usuario"]:
        raise HTTPException(404, "La compra no existe")
    if compra["estado"] != "pendiente":
        raise HTTPException(409, f"La compra ya está {compra['estado']}")
    cot = compras.get(f"/internal/compras/{datos.id_compra}/cotizacion")
    ev = eventos.get(f"/internal/eventos/{cot['id_evento']}")
    if ev["estado"] != "programado":
        raise HTTPException(409, f"El evento está {ev['estado']}: no se puede pagar")

    id_usr, id_res = info["id_usuario"], compra["id_reserva"]

    # ---------- Pago rechazado (RN17) ----------
    if datos.numero_tarjeta == TARJETA_RECHAZO:
        p = _registrar(db, datos.id_compra, cot["total"], "rechazado")
        compras.post(f"/internal/compras/{datos.id_compra}/estado", {"estado": "rechazada"})
        reservas.post(f"/internal/reservas/{id_res}/liberar")
        notificar(id_usr, "pago", datos.id_compra,
                  f"El pago de tu compra #{datos.id_compra} fue rechazado; los asientos se liberaron.")
        auditoria.registrar("PAGO_RECHAZADO", "PAGO", p.id_pago, id_usr, f"compra {datos.id_compra}")
        return {**_salida(p), "boletas": [], "mensaje": "El banco rechazó el pago. Los asientos se liberaron."}

    # ---------- Pago aprobado ----------
    # Primero se asegura la venta de los asientos; si la reserva expiró no se cobra nada.
    try:
        reservas.post(f"/internal/reservas/{id_res}/completar")
    except ErrorServicio as e:
        if e.status == 409:  # expirada/cancelada: Reservas ya anuló la compra pendiente
            raise HTTPException(409, f"{e.detalle}. No se realizó ningún cobro.")
        raise
    p = _registrar(db, datos.id_compra, cot["total"], "aprobado")
    compras.post(f"/internal/compras/{datos.id_compra}/estado", {"estado": "pagada", "valor_total": cot["total"]})
    emitidas, aviso = [], None
    try:
        emitidas = boletas.post("/internal/boletas/generar", {
            "id_compra": datos.id_compra, "id_evento": cot["id_evento"],
            "items": [{"id_asiento": i["id_asiento"], "precio": i["precio"]} for i in cot["items"]]})
    except (ErrorServicio, ServicioNoDisponible) as exc:
        aviso = f"El pago se aprobó pero las boletas aún no se emitieron: {exc}"
    notificar(id_usr, "pago", datos.id_compra,
              f"¡Pago aprobado! Tus {len(emitidas)} boleta(s) para «{ev['nombre']}» ya están disponibles.")
    auditoria.registrar("PAGO_APROBADO", "PAGO", p.id_pago, id_usr,
                        f"compra {datos.id_compra}, valor {cot['total']}")
    return {**_salida(p), "boletas": emitidas, "mensaje": aviso or "Pago aprobado"}


@router.get("/pagos/compra/{id_compra}", tags=["Pagos"],
            summary="RF-PAG-02 Estado más reciente del pago de una compra")
def estado_pago(id_compra: int, info: dict = Depends(sesion_actual), db: Session = Depends(get_db)):
    compra = compras.get_o_none(f"/internal/compras/{id_compra}")
    if compra is None or (compra["id_usuario"] != info["id_usuario"] and not es_admin(info)):
        raise HTTPException(404, "La compra no existe")
    p = db.scalar(select(Pago).where(Pago.id_compra == id_compra).order_by(Pago.id_pago.desc()).limit(1))
    if p is None:
        raise HTTPException(404, "La compra aún no tiene pagos")
    return _salida(p)


@router.get("/pagos", tags=["Administración"], summary="Pagos registrados (administrador)")
def listar(_: dict = Depends(requiere("consultar_auditoria")), db: Session = Depends(get_db)):
    return [_salida(p) for p in db.scalars(select(Pago).order_by(Pago.id_pago.desc()).limit(200))]


app = crear_app("pagos", "Microservicio de Pagos",
                "Registro y consulta del pago (simulado) de cada compra (RF-PAG-01 a 03).",
                router, Base, engine, preparar)
